export const environment = {
  production: true,  
  apiUrl: 'https://api.autoforce.io/public/api/',
  website: 'https://www.autoforce.io',
  reviewLink: 'https://pwa.autoforce.io',	
  cmsUrl: 'https://cms.autoforce.io'
};
