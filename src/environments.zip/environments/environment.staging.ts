export const environment = {
  production: true,
  apiUrl: 'https://staging-api.autoforce.io/public/api/',
  website: 'https://www.autoforce.io',
  reviewLink: 'https://staging-pwa.autoforce.io',
  cmsUrl: 'https://staging-cms.autoforce.io'
};
